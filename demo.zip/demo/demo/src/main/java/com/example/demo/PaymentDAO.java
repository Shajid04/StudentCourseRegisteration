package com.example.demo;

public interface PaymentDAO {
	void insertDetails(Payment p);
}
