package com.example.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="feedback")
public class Feedback {
	
	@Id
	@Column(name="formName")
	private String formName;
	@Column(name="formEmail")
	private String formEmail;
	@Column(name="formMessage")
	private String formMessage;
	public Feedback(String formName, String formEmail, String formMessage) {
		super();
		this.formName = formName;
		this.formEmail = formEmail;
		this.formMessage = formMessage;
	}
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getFormEmail() {
		return formEmail;
	}
	public void setFormEmail(String formEmail) {
		this.formEmail = formEmail;
	}
	public String getFormMessage() {
		return formMessage;
	}
	public void setFormMessage(String formMessage) {
		this.formMessage = formMessage;
	}
	

}
