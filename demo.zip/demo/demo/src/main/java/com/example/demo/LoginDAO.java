package com.example.demo;

public interface LoginDAO {
	void insertdata(Login lg);

}
