package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class Rest {
    private final RegisterDAOClass rdc;
    private final LoginDAOClass ldc;
    private final FeedbackDAOClass fdc;
    private final PaymentDAOClass pdc;

    @Autowired
    public Rest(RegisterDAOClass rdc, LoginDAOClass ldc,FeedbackDAOClass fdc,PaymentDAOClass pdc) {
        this.rdc = rdc;
        this.ldc = ldc;
        this.fdc = fdc;
        this.pdc=pdc;
    }
    @GetMapping("/")
    public String showHomePage() {
        return "Home";
    }
    @GetMapping("/adminlogin")
    public String adminlogin() {
        return "adminlogin";
    }
    @GetMapping("/facultylogin")
    public String facultylogin() {
        return "facultylogin";
    }
    @GetMapping("/fdashboard")
    public String fdashboard() {
        return "fdashboard";
    }
    @GetMapping("/Addcourse")
    public String Addcourse() {
        return "Addcourse";
    }
    @GetMapping("/admindash")
    public String admindash() {
        return "admindash";
    }
    @GetMapping("/chatbot")
    public String chatbot() {
        return "chatbot";
    }
    
    @GetMapping("/coursepurchase")
    public String coursepurchase() {
        return "coursepurchase";
    }
    @GetMapping("/scheduleplanner")
    public String scheduleplanner() {
        return "scheduleplanner";
    }
    @GetMapping("/courseregister")
    public String courseregister() {
        return "courseregister";
    }
    @GetMapping("/studash")
    public String studash() {
        return "studash";
    }
    @GetMapping("/reg")
    public String reg() {
        return "reg";
    }
 
 
   
    @GetMapping("/feedback")
    public String feedback(Model model) {
        model.addAttribute("s2", new Feedback());
        return "feedback";
    }

    @PostMapping("/feed_user")
    public String feedUser(@ModelAttribute("s2") Feedback user2, Model model) {
        model.addAttribute("s1", user2);
        fdc.insertdata(user2);
        return "fdashboard";
    }
    

    @GetMapping("/register")
    public String signup(Model model) {
        model.addAttribute("sp2", new Register());
        return "register";
    }

    @PostMapping("/add_user")
    public String addUser(@ModelAttribute("sp2") Register user2, Model model) {
        model.addAttribute("sp2", user2);
        rdc.insertdata(user2);
        return "Login";
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("sp3", new Login());
        return "login";
    }

    @PostMapping("/login_user")
    public String loginUser(@ModelAttribute("sp3") Login user2, Model model) {
        model.addAttribute("sp2", user2);
        ldc.insertdata(user2);
        return "studash";
    }
    
    @GetMapping("/payment")
    public String showPayment(Model model) {
        model.addAttribute("p2", new Payment());
        return "Payment";
    }
    
    @PostMapping("/add_pay")
    public String addPay(@ModelAttribute("p2") Payment user, Model model) {
        model.addAttribute("p1", user);
        pdc.insertDetails(user);
        return "studash";
    }
    
    
    
    
}