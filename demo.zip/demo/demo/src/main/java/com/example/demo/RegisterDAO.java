package com.example.demo;

public interface RegisterDAO {
	void insertdata(Register rg);
}
