package com.example.demo;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class RegisterDAOClass implements RegisterDAO{

	@Autowired
	public RegisterRepo rp;
	
	@Override
	public void insertdata(Register rg) {
		// TODO Auto-generated method stub
		rp.save(rg);
	}

	public Optional<Register> findpathbyId(String uname) {
		// TODO Auto-generated method stub
		return rp.findByUname(uname);
	}

}
