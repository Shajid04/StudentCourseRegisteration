package com.example.demo;

public interface FeedbackDAO {
	void insertdata(Feedback fb);

}
