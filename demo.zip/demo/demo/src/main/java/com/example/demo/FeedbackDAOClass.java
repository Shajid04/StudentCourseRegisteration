package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedbackDAOClass implements FeedbackDAO {
    @Autowired
    private FeedbackRepo fp;

    @Override
    public void insertdata(Feedback fb) {
    	if (fb.getFormName() == null || fb.getFormName().isEmpty()) {
            fb.setFormName("DefaultName"); // Set a default value if needed
        }
        fp.save(fb);
    }
}

